import streamlit as st
from pathlib import Path
import uuid
from app.config import APP_NAME, OUTPUT_DIR, OPENAI_API_KEY, OPENAI_MODEL
from app.storyboard import create_storyboard
from app.voice import create_voiceover
from app.render import render_video
from app.subtitles import create_srt

st.set_page_config(page_title=APP_NAME, page_icon="🎬", layout="wide")
st.markdown("""
<style>
.main {background: #10111b;}
.block-container {padding-top: 2rem; max-width: 1250px;}
h1, h2, h3 {letter-spacing: -.5px;}
.stButton>button {border-radius: 10px; font-weight: 650;}
</style>
""", unsafe_allow_html=True)
st.title("🎬 ANH HƯỚNG NỘI AI STUDIO")
st.caption("Biến văn bản thành video kể chuyện – phiên bản MVP chạy trên máy tính.")
with st.sidebar:
    st.header("⚙️ Cấu hình")
    ratio = st.selectbox("Tỷ lệ video", ["16:9 – YouTube", "9:16 – TikTok/Reels"])
    scenes_count = st.slider("Số cảnh tối đa", 2, 12, 6)
    seconds = st.slider("Thời lượng mỗi cảnh (giây)", 3, 12, 5)
    make_voice = st.checkbox("Tạo giọng đọc tiếng Việt", True)
    voice = st.selectbox("Giọng đọc", ["vi-VN-NamMinhNeural", "vi-VN-HoaiMyNeural"])
    use_ai = st.checkbox("Dùng OpenAI để biên tập kịch bản", bool(OPENAI_API_KEY))
    api_key = st.text_input("OpenAI API key (không bắt buộc)", type="password",
                            value=OPENAI_API_KEY)
    model = st.text_input("Tên model", OPENAI_MODEL)
    st.info("Không nhập API key vẫn có thể chia cảnh và dựng video cơ bản.")

left, right = st.columns([1.15, .85], gap="large")
with left:
    st.subheader("1. Nội dung đầu vào")
    text = st.text_area("Dán câu chuyện, bài viết hoặc kịch bản tại đây",
        height=260, placeholder="Ví dụ: Một chàng trai trở về quê sau nhiều năm xa cách...")
    style = st.selectbox("Phong cách nội dung", [
        "Điện ảnh, cảm xúc", "Tài liệu", "Quảng cáo sản phẩm",
        "Truyền thông", "Hoạt hình", "Kể chuyện chữa lành"])
    uploaded = st.file_uploader("Ảnh minh họa cho các cảnh (tùy chọn)",
        type=["png", "jpg", "jpeg"], accept_multiple_files=True)
    create = st.button("✨ PHÂN TÍCH & TẠO STORYBOARD", type="primary", use_container_width=True)
with right:
    st.subheader("2. Quy trình")
    st.markdown("""
    1. Phân tích nội dung và chia cảnh.
    2. Tạo lời dẫn và gợi ý hình ảnh.
    3. Tạo giọng đọc tiếng Việt (tùy chọn).
    4. Dựng video MP4 bằng FFmpeg.
    5. Xuất phụ đề SRT.
    """)
    st.warning("Bản MVP tạo video dạng slideshow từ ảnh tải lên hoặc thẻ cảnh tự sinh; chưa sinh chuyển động video AI.")
if create:
    if not text.strip():
        st.error("Bạn hãy nhập nội dung trước.")
    else:
        try:
            with st.spinner("Đang phân tích nội dung..."):
                scenes = create_storyboard(text, scenes_count, use_ai, api_key, model)
            st.session_state["scenes"] = scenes
            st.session_state["job_id"] = uuid.uuid4().hex[:10]
            st.success(f"Đã tạo {len(scenes)} cảnh.")
        except Exception as exc:
            st.error(str(exc))

scenes = st.session_state.get("scenes", [])
if scenes:
    st.divider()
    st.subheader("3. Storyboard – kiểm tra và chỉnh sửa")
    for i, scene in enumerate(scenes):
        with st.expander(f"{i+1}. {scene['title']}", expanded=(i == 0)):
            scene["title"] = st.text_input("Tiêu đề", scene["title"], key=f"title_{i}")
            scene["narration"] = st.text_area("Lời đọc", scene["narration"], key=f"narr_{i}")
            scene["visual_prompt"] = st.text_area("Gợi ý hình ảnh", scene["visual_prompt"], key=f"prompt_{i}")
    if st.button("🎞️ DỰNG VIDEO MP4", type="primary", use_container_width=True):
        job = st.session_state.get("job_id", "video")
        image_paths = []
        if uploaded:
            for i, file in enumerate(uploaded):
                path = OUTPUT_DIR / f"{job}_image_{i}{Path(file.name).suffix.lower()}"
                path.write_bytes(file.getvalue())
                image_paths.append(str(path))
        voice_path = None
        try:
            if make_voice:
                with st.spinner("Đang tạo giọng đọc..."):
                    voice_path = create_voiceover(
                        " ".join(s["narration"] for s in scenes),
                        OUTPUT_DIR / f"{job}_voice.mp3", voice)
            width, height = (1280, 720) if ratio.startswith("16:9") else (720, 1280)
            with st.spinner("FFmpeg đang dựng video..."):
                video_path = render_video(scenes, OUTPUT_DIR / f"{job}.mp4",
                    voice_path, image_paths, seconds, width=width, height=height)
                srt_path = create_srt(scenes, OUTPUT_DIR / f"{job}.srt", seconds)
            st.success("Đã dựng video thành công!")
            st.video(str(video_path))
            st.download_button("⬇️ Tải video MP4", video_path.read_bytes(),
                file_name="anh-huong-noi-ai-studio.mp4", mime="video/mp4")
            st.download_button("⬇️ Tải phụ đề SRT", srt_path.read_bytes(),
                file_name="phu-de.srt", mime="text/plain")
        except Exception as exc:
            st.error(f"Không thể dựng video: {exc}")
            st.caption("Hãy kiểm tra FFmpeg và kết nối mạng nếu đang tạo giọng đọc.")
st.divider()
st.caption("ANH HƯỚNG NỘI AI STUDIO • Local-first • Open-source components")
