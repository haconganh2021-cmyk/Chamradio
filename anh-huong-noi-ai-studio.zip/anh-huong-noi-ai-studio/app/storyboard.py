"""Tạo storyboard từ văn bản; có chế độ AI và chế độ offline."""
import json
import re
from typing import Any

def _split_sentences(text: str) -> list[str]:
    cleaned = re.sub(r"\s+", " ", text).strip()
    if not cleaned:
        return []
    parts = re.split(r"(?<=[.!?…])\s+", cleaned)
    return [p.strip() for p in parts if p.strip()]

def create_storyboard(text: str, scenes_count: int = 6, use_ai: bool = False,
                      api_key: str = "", model: str = "gpt-4o-mini") -> list[dict[str, Any]]:
    """Trả về danh sách cảnh với narration và visual_prompt."""
    if not text or not text.strip():
        raise ValueError("Vui lòng nhập nội dung trước khi tạo kịch bản.")
    if use_ai and api_key:
        try:
            from openai import OpenAI
            client = OpenAI(api_key=api_key)
            response = client.chat.completions.create(
                model=model,
                temperature=0.7,
                response_format={"type": "json_object"},
                messages=[
                    {"role": "system", "content":
                     "Bạn là biên kịch video. Trả về JSON có key scenes, là mảng cảnh. "
                     "Mỗi cảnh có title, narration, visual_prompt. Viết tiếng Việt. "
                     "Chia nội dung thành số cảnh hợp lý, không bịa sai ý chính."},
                    {"role": "user", "content":
                     f"Chia nội dung sau thành tối đa {scenes_count} cảnh:\n{text}"}
                ],
            )
            data = json.loads(response.choices[0].message.content or "{}")
            scenes = data.get("scenes", [])
            if scenes:
                return [
                    {"title": str(s.get("title", f"Cảnh {i+1}")),
                     "narration": str(s.get("narration", "")),
                     "visual_prompt": str(s.get("visual_prompt", ""))}
                    for i, s in enumerate(scenes[:scenes_count])
                ]
        except Exception as exc:
            raise RuntimeError(f"Không gọi được AI API: {exc}") from exc

    sentences = _split_sentences(text)
    if not sentences:
        sentences = [text.strip()]
    n = min(max(1, scenes_count), len(sentences))
    groups = [[] for _ in range(n)]
    for i, sentence in enumerate(sentences):
        groups[min(i * n // len(sentences), n - 1)].append(sentence)
    scenes = []
    for i, group in enumerate(groups):
        narration = " ".join(group)
        scenes.append({
            "title": f"Cảnh {i+1}",
            "narration": narration,
            "visual_prompt": f"Hình ảnh điện ảnh minh họa cho nội dung: {narration}"
        })
    return scenes
