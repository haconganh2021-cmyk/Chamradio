from pathlib import Path
import re

def _timestamp(seconds: float) -> str:
    ms = int(seconds * 1000)
    h, ms = divmod(ms, 3600000)
    m, ms = divmod(ms, 60000)
    s, ms = divmod(ms, 1000)
    return f"{h:02}:{m:02}:{s:02},{ms:03}"

def create_srt(scenes: list[dict], output_path: str | Path,
               seconds_per_scene: int = 5) -> Path:
    rows = []
    for i, scene in enumerate(scenes):
        start = i * seconds_per_scene
        end = (i + 1) * seconds_per_scene
        rows.extend([str(i+1), f"{_timestamp(start)} --> {_timestamp(end)}",
                     scene.get("narration", ""), ""])
    path = Path(output_path)
    path.write_text("\n".join(rows), encoding="utf-8")
    return path
