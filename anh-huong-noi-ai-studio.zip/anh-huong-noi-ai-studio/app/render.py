"""Dựng video slideshow MP4 bằng FFmpeg."""
from pathlib import Path
import subprocess
import tempfile
from PIL import Image, ImageDraw, ImageFont
import textwrap

def _font(size=44):
    candidates = [
        "C:/Windows/Fonts/arial.ttf",
        "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf",
        "/System/Library/Fonts/Supplemental/Arial.ttf",
    ]
    for item in candidates:
        if Path(item).exists():
            return ImageFont.truetype(item, size)
    return ImageFont.load_default()

def make_title_card(title: str, narration: str, output: str | Path,
                    width: int = 1280, height: int = 720):
    img = Image.new("RGB", (width, height), (22, 24, 38))
    draw = ImageDraw.Draw(img)
    # Gradient nền đơn giản
    for y in range(height):
        c = int(24 + 35 * y / height)
        draw.line((0, y, width, y), fill=(c, 25, 55))
    draw.rounded_rectangle((70, 70, width-70, height-70), radius=28,
                           outline=(132, 102, 220), width=3)
    draw.text((110, 125), title, font=_font(48), fill=(245, 240, 255))
    lines = textwrap.wrap(narration, width=48)
    y = 245
    for line in lines[:7]:
        draw.text((115, y), line, font=_font(29), fill=(225, 225, 238))
        y += 48
    draw.text((110, height-125), "ANH HƯỚNG NỘI AI STUDIO",
              font=_font(22), fill=(175, 155, 225))
    Path(output).parent.mkdir(parents=True, exist_ok=True)
    img.save(output, quality=94)

def _run(cmd):
    result = subprocess.run(cmd, capture_output=True, text=True)
    if result.returncode:
        raise RuntimeError(result.stderr[-2500:] or "FFmpeg không thể dựng video.")

def render_video(scenes: list[dict], output_path: str | Path,
                 voice_path: str | Path | None = None,
                 uploaded_images: list[str] | None = None,
                 seconds_per_scene: int = 5, fps: int = 25,
                 width: int = 1280, height: int = 720) -> Path:
    if not scenes:
        raise ValueError("Chưa có cảnh để dựng video.")
    output = Path(output_path)
    output.parent.mkdir(parents=True, exist_ok=True)
    uploaded_images = uploaded_images or []
    with tempfile.TemporaryDirectory() as tmp:
        tmpdir = Path(tmp)
        concat_file = tmpdir / "inputs.txt"
        image_paths = []
        for i, scene in enumerate(scenes):
            target = tmpdir / f"scene_{i:03d}.jpg"
            source = uploaded_images[i] if i < len(uploaded_images) else None
            if source and Path(source).exists():
                with Image.open(source) as im:
                    im.convert("RGB").resize((width, height)).save(target, quality=92)
            else:
                make_title_card(scene.get("title", f"Cảnh {i+1}"),
                                scene.get("narration", ""), target, width, height)
            image_paths.append(target)
        # Tạo clip từng cảnh rồi nối để tránh sai thời lượng concat ảnh.
        clips = []
        for i, image in enumerate(image_paths):
            clip = tmpdir / f"clip_{i:03d}.mp4"
            _run(["ffmpeg", "-y", "-loop", "1", "-i", str(image),
                  "-t", str(seconds_per_scene), "-r", str(fps),
                  "-vf", f"scale={width}:{height},format=yuv420p",
                  "-an", "-c:v", "libx264", "-preset", "veryfast",
                  str(clip)])
            clips.append(clip)
        concat_file.write_text("".join(f"file '{p.as_posix()}'\n" for p in clips), encoding="utf-8")
        silent = tmpdir / "silent.mp4"
        _run(["ffmpeg", "-y", "-f", "concat", "-safe", "0", "-i", str(concat_file),
              "-c", "copy", str(silent)])
        if voice_path and Path(voice_path).exists():
            _run(["ffmpeg", "-y", "-i", str(silent), "-i", str(voice_path),
                  "-map", "0:v:0", "-map", "1:a:0", "-c:v", "copy",
                  "-c:a", "aac", "-shortest", "-movflags", "+faststart", str(output)])
        else:
            _run(["ffmpeg", "-y", "-i", str(silent), "-c", "copy",
                  "-movflags", "+faststart", str(output)])
    return output
