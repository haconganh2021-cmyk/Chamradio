"""Tạo giọng đọc tiếng Việt bằng Edge TTS."""
import asyncio
from pathlib import Path

async def _save_tts(text: str, output_path: str, voice: str, rate: str):
    import edge_tts
    communicate = edge_tts.Communicate(text=text, voice=voice, rate=rate)
    await communicate.save(output_path)

def create_voiceover(text: str, output_path: str | Path,
                     voice: str = "vi-VN-NamMinhNeural", rate: str = "+0%") -> Path:
    if not text.strip():
        raise ValueError("Nội dung giọng đọc đang trống.")
    path = Path(output_path)
    path.parent.mkdir(parents=True, exist_ok=True)
    try:
        asyncio.run(_save_tts(text, str(path), voice, rate))
    except RuntimeError:
        loop = asyncio.new_event_loop()
        try:
            loop.run_until_complete(_save_tts(text, str(path), voice, rate))
        finally:
            loop.close()
    return path
