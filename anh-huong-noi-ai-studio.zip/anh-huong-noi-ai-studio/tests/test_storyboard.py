from app.storyboard import create_storyboard

def test_offline_storyboard_splits_text():
    scenes = create_storyboard("Xin chào. Đây là cảnh hai. Cảnh cuối!", scenes_count=3)
    assert len(scenes) == 3
    assert all(scene["narration"] for scene in scenes)
    assert all("visual_prompt" in scene for scene in scenes)

def test_empty_text_raises():
    try:
        create_storyboard("   ")
    except ValueError:
        return
    assert False, "Expected ValueError"
