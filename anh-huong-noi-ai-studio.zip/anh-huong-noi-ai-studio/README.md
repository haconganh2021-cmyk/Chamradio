# ANH HƯỚNG NỘI AI STUDIO

Ứng dụng web Python biến văn bản thành storyboard, giọng đọc tiếng Việt, video MP4 dạng slideshow và phụ đề SRT.

> **Phạm vi MVP:** Video hiện được dựng từ ảnh người dùng tải lên hoặc thẻ cảnh do ứng dụng tạo. Đây chưa phải mô hình sinh video chuyển động AI. Kiến trúc được chia module để có thể tích hợp Wan/ComfyUI hoặc dịch vụ video AI ở giai đoạn sau.

## Tính năng

- Nhập câu chuyện, bài viết hoặc kịch bản.
- Chia văn bản thành cảnh ở chế độ offline.
- Tùy chọn dùng OpenAI để biên tập storyboard (cần API key riêng).
- Chỉnh sửa tiêu đề, lời đọc và gợi ý hình ảnh từng cảnh.
- Tạo giọng đọc tiếng Việt bằng Edge TTS (cần Internet).
- Dùng ảnh tải lên hoặc thẻ cảnh tự sinh.
- Dựng MP4 bằng FFmpeg; xuất phụ đề SRT.
- Hỗ trợ khung hình 16:9 và 9:16.

## Yêu cầu

- Windows 10/11 64-bit
- Python 3.10 trở lên (khuyến nghị 3.11)
- FFmpeg có trong PATH
- Kết nối Internet nếu dùng Edge TTS hoặc OpenAI API

## Cài đặt trên Windows

### 1. Cài phần mềm

Cài Python từ https://www.python.org/downloads/windows/ (đánh dấu **Add Python to PATH**).
Cài FFmpeg và thêm thư mục `bin` vào biến môi trường PATH. Kiểm tra bằng:

```powershell
python --version
ffmpeg -version
```

### 2. Tải mã nguồn

```powershell
git clone https://github.com/YOUR_USERNAME/anh-huong-noi-ai-studio.git
cd anh-huong-noi-ai-studio
```

Hoặc tải ZIP từ GitHub và giải nén.

### 3. Tạo môi trường và cài thư viện

```powershell
py -3.11 -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
pip install -r requirements.txt
```

Nếu PowerShell chặn kích hoạt môi trường, chạy lệnh sau trong cửa sổ PowerShell hiện tại:

```powershell
Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
.\.venv\Scripts\Activate.ps1
```

### 4. Chạy ứng dụng

```powershell
streamlit run streamlit_app.py
```

Trình duyệt sẽ mở địa chỉ cục bộ, thường là `http://localhost:8501`.

## Dùng OpenAI (không bắt buộc)

Sao chép `.env.example` thành `.env`, sau đó thêm API key của bạn:

```env
OPENAI_API_KEY=your_api_key_here
OPENAI_MODEL=gpt-4o-mini
```

Không bao giờ commit file `.env` lên GitHub. API sử dụng có thể phát sinh chi phí riêng; ứng dụng vẫn chạy chế độ offline nếu không cấu hình key.

## Dùng ứng dụng

1. Dán nội dung vào ô văn bản.
2. Chọn số cảnh, tỷ lệ video và giọng đọc.
3. Nhấn **Phân tích & tạo storyboard**.
4. Chỉnh sửa lời đọc và gợi ý hình ảnh.
5. Tải ảnh minh họa nếu có.
6. Nhấn **Dựng video MP4**.
7. Tải video và phụ đề SRT.

## Đưa dự án lên GitHub

Tạo repository tên `anh-huong-noi-ai-studio`, sau đó trong thư mục dự án chạy:

```powershell
git init
git add .
git commit -m "Initial release: Anh Huong Noi AI Studio MVP"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/anh-huong-noi-ai-studio.git
git push -u origin main
```

Thay `YOUR_USERNAME` bằng tên tài khoản GitHub của bạn.

## Cấu trúc thư mục

```text
anh-huong-noi-ai-studio/
├── .github/workflows/tests.yml
├── app/
│   ├── config.py
│   ├── storyboard.py
│   ├── voice.py
│   ├── render.py
│   └── subtitles.py
├── outputs/
├── tests/
├── .env.example
├── .gitignore
├── requirements.txt
├── streamlit_app.py
└── README.md
```

## Giới hạn và hướng phát triển

- MVP tạo slideshow MP4, chưa sinh video chuyển động từ prompt.
- Edge TTS cần Internet và phụ thuộc khả năng cung cấp của dịch vụ.
- Tạo ảnh AI, sinh video AI và đồng bộ khẩu hình sẽ được bổ sung thành provider riêng.
- Chạy mô hình video cục bộ phụ thuộc model GPU, VRAM, dung lượng ổ đĩa và khả năng tương thích.

## Bảo mật

- Không đưa API key, mật khẩu hoặc token vào mã nguồn.
- Không commit `.env`, video đầu ra hoặc dữ liệu cá nhân.
- Kiểm tra giấy phép và điều khoản của từng model/dịch vụ trước khi phân phối thương mại.
